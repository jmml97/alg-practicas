#ifndef ALGORITMOS_H_INCLUDED
#define ALGORITMOS_H_INCLUDED

#include "Problema.h"
#include "Solucion.h"

int FSeleccion(int* LC, int N);

Solucion RecubrimientoGrafoGreedy(const Problema& p);

#endif // ALGORITMOS_H_INCLUDED
